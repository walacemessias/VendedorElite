import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Target, Plus, Edit, Calendar, Trophy, Eye, EyeOff } from 'lucide-react';
import { Campaign, CampaignPeriod } from '../types';

export const Campaigns: React.FC = () => {
  const { campaigns, createCampaign, teams, activeTeam } = useApp();
  const { hasPermission } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    teamId: activeTeam?.id || '',
    period: 'monthly' as CampaignPeriod,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    autoReset: true,
    hideValues: false,
    prizes: [
      { position: 1, name: 'Primeiro Lugar', description: 'Prêmio para o campeão', icon: '🏆', visible: true },
      { position: 2, name: 'Segundo Lugar', description: 'Prêmio para o vice-campeão', icon: '🥈', visible: true },
      { position: 3, name: 'Terceiro Lugar', description: 'Prêmio para o terceiro colocado', icon: '🥉', visible: true }
    ]
  });

  const canManageCampaigns = hasPermission('manage') || hasPermission('all');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const campaignData = {
      ...formData,
      startDate: new Date(formData.startDate),
      endDate: new Date(formData.endDate),
      prizes: formData.prizes.map((prize, index) => ({
        ...prize,
        id: `prize-${Date.now()}-${index}`
      })),
      targets: [],
      isActive: true
    };

    createCampaign(campaignData);
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      name: '',
      teamId: activeTeam?.id || '',
      period: 'monthly',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      autoReset: true,
      hideValues: false,
      prizes: [
        { position: 1, name: 'Primeiro Lugar', description: 'Prêmio para o campeão', icon: '🏆', visible: true },
        { position: 2, name: 'Segundo Lugar', description: 'Prêmio para o vice-campeão', icon: '🥈', visible: true },
        { position: 3, name: 'Terceiro Lugar', description: 'Prêmio para o terceiro colocado', icon: '🥉', visible: true }
      ]
    });
    setShowForm(false);
    setEditingCampaign(null);
  };

  const getPeriodLabel = (period: CampaignPeriod) => {
    const labels = {
      monthly: 'Mensal',
      bimonthly: 'Bimestral',
      quarterly: 'Trimestral',
      semiannual: 'Semestral',
      custom: 'Personalizado'
    };
    return labels[period];
  };

  const getStatusColor = (campaign: Campaign) => {
    const now = new Date();
    if (now < campaign.startDate) return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    if (now > campaign.endDate) return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
  };

  const getStatusLabel = (campaign: Campaign) => {
    const now = new Date();
    if (now < campaign.startDate) return 'Agendada';
    if (now > campaign.endDate) return 'Finalizada';
    return 'Ativa';
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <Target className="w-8 h-8 mr-3 text-blue-500" />
            Campanhas
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Gerencie campanhas e metas por time
          </p>
        </div>
        
        {canManageCampaigns && (
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Nova Campanha</span>
          </button>
        )}
      </div>

      {/* Campaigns Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {campaigns.map((campaign) => (
          <div
            key={campaign.id}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 dark:text-white text-lg">
                    {campaign.name}
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {teams.find(t => t.id === campaign.teamId)?.name}
                  </p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(campaign)}`}>
                  {getStatusLabel(campaign)}
                </span>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Período:</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {getPeriodLabel(campaign.period)}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Início:</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {campaign.startDate.toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Fim:</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {campaign.endDate.toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Auto Reset:</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {campaign.autoReset ? 'Sim' : 'Não'}
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Valores:</span>
                  <div className="flex items-center">
                    {campaign.hideValues ? (
                      <EyeOff className="w-4 h-4 text-gray-500" />
                    ) : (
                      <Eye className="w-4 h-4 text-green-500" />
                    )}
                    <span className="text-gray-900 dark:text-white font-medium ml-1">
                      {campaign.hideValues ? 'Ocultos' : 'Visíveis'}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                      <Trophy className="w-4 h-4 mr-1" />
                      <span>{campaign.prizes.filter(p => p.visible).length} prêmios</span>
                    </div>
                    {canManageCampaigns && (
                      <button 
                        onClick={() => {
                          setEditingCampaign(campaign);
                          setFormData({
                            name: campaign.name,
                            teamId: campaign.teamId,
                            period: campaign.period,
                            startDate: campaign.startDate.toISOString().split('T')[0],
                            endDate: campaign.endDate.toISOString().split('T')[0],
                            autoReset: campaign.autoReset,
                            hideValues: campaign.hideValues,
                            prizes: campaign.prizes.map(p => ({ ...p }))
                          });
                          setShowForm(true);
                        }}
                        className="p-1 text-gray-400 hover:text-blue-500 transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Create/Edit Campaign Form */}
      {showForm && canManageCampaigns && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingCampaign ? 'Editar Campanha' : 'Criar Nova Campanha'}
              </h3>
              <button
                onClick={resetForm}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Nome da Campanha
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="Digite o nome da campanha"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Time
                  </label>
                  <select
                    value={formData.teamId}
                    onChange={(e) => setFormData(prev => ({ ...prev, teamId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    required
                  >
                    <option value="">Selecione o time</option>
                    {teams.map((team) => (
                      <option key={team.id} value={team.id}>
                        {team.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Período
                  </label>
                  <select
                    value={formData.period}
                    onChange={(e) => setFormData(prev => ({ ...prev, period: e.target.value as CampaignPeriod }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  >
                    <option value="monthly">Mensal</option>
                    <option value="bimonthly">Bimestral</option>
                    <option value="quarterly">Trimestral</option>
                    <option value="semiannual">Semestral</option>
                    <option value="custom">Personalizado</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Data de Início
                  </label>
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Data de Fim
                  </label>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center space-x-6">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.autoReset}
                    onChange={(e) => setFormData(prev => ({ ...prev, autoReset: e.target.checked }))}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                    Reset automático ao final
                  </span>
                </label>

                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.hideValues}
                    onChange={(e) => setFormData(prev => ({ ...prev, hideValues: e.target.checked }))}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                    Ocultar valores (mostrar só %)
                  </span>
                </label>
              </div>

              {/* Prizes Section */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Premiações
                </h4>
                <div className="space-y-4">
                  {formData.prizes.map((prize, index) => (
                    <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                      <div className="grid md:grid-cols-4 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Posição
                          </label>
                          <input
                            type="text"
                            value={`${prize.position}º Lugar`}
                            disabled
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Nome do Prêmio
                          </label>
                          <input
                            type="text"
                            value={prize.name}
                            onChange={(e) => {
                              const newPrizes = [...formData.prizes];
                              newPrizes[index].name = e.target.value;
                              setFormData(prev => ({ ...prev, prizes: newPrizes }));
                            }}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Ícone
                          </label>
                          <input
                            type="text"
                            value={prize.icon}
                            onChange={(e) => {
                              const newPrizes = [...formData.prizes];
                              newPrizes[index].icon = e.target.value;
                              setFormData(prev => ({ ...prev, prizes: newPrizes }));
                            }}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                            placeholder="🏆"
                          />
                        </div>
                        <div className="flex items-end">
                          <label className="flex items-center">
                            <input
                              type="checkbox"
                              checked={prize.visible}
                              onChange={(e) => {
                                const newPrizes = [...formData.prizes];
                                newPrizes[index].visible = e.target.checked;
                                setFormData(prev => ({ ...prev, prizes: newPrizes }));
                              }}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                              Visível
                            </span>
                          </label>
                        </div>
                      </div>
                      <div className="mt-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Descrição
                        </label>
                        <textarea
                          value={prize.description}
                          onChange={(e) => {
                            const newPrizes = [...formData.prizes];
                            newPrizes[index].description = e.target.value;
                            setFormData(prev => ({ ...prev, prizes: newPrizes }));
                          }}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                          rows={2}
                          placeholder="Descrição do prêmio"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                >
                  {editingCampaign ? 'Atualizar Campanha' : 'Criar Campanha'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};