import React from 'react';
import { PodiumCard } from '../components/Dashboard/PodiumCard';
import { RankingTable } from '../components/Dashboard/RankingTable';
import { useApp } from '../context/AppContext';
import { Trophy, Medal, Award } from 'lucide-react';

export const Ranking: React.FC = () => {
  const { ranking, activeCampaign } = useApp();

  const podiumStats = {
    first: ranking.find(r => r.position === 1),
    second: ranking.find(r => r.position === 2),
    third: ranking.find(r => r.position === 3)
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <Trophy className="w-8 h-8 mr-3 text-yellow-500" />
            Ranking
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {activeCampaign?.name || 'Campanha Ativa'} • 
            Classificação em tempo real
          </p>
        </div>
      </div>

      {/* Podium Highlights */}
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Trophy className="w-8 h-8" />
            <span className="text-2xl font-bold">1º</span>
          </div>
          {podiumStats.first ? (
            <div>
              <h3 className="font-bold text-lg">{podiumStats.first.sellerName}</h3>
              <p className="opacity-90">{podiumStats.first.achievement}% da meta</p>
              <p className="text-sm opacity-75">
                R$ {podiumStats.first.value.toLocaleString('pt-BR')}
              </p>
            </div>
          ) : (
            <div className="text-yellow-100">
              <p>Aguardando primeiro colocado</p>
            </div>
          )}
        </div>

        <div className="bg-gradient-to-br from-gray-400 to-gray-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Medal className="w-8 h-8" />
            <span className="text-2xl font-bold">2º</span>
          </div>
          {podiumStats.second ? (
            <div>
              <h3 className="font-bold text-lg">{podiumStats.second.sellerName}</h3>
              <p className="opacity-90">{podiumStats.second.achievement}% da meta</p>
              <p className="text-sm opacity-75">
                R$ {podiumStats.second.value.toLocaleString('pt-BR')}
              </p>
            </div>
          ) : (
            <div className="text-gray-100">
              <p>Aguardando segundo colocado</p>
            </div>
          )}
        </div>

        <div className="bg-gradient-to-br from-amber-600 to-amber-800 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Award className="w-8 h-8" />
            <span className="text-2xl font-bold">3º</span>
          </div>
          {podiumStats.third ? (
            <div>
              <h3 className="font-bold text-lg">{podiumStats.third.sellerName}</h3>
              <p className="opacity-90">{podiumStats.third.achievement}% da meta</p>
              <p className="text-sm opacity-75">
                R$ {podiumStats.third.value.toLocaleString('pt-BR')}
              </p>
            </div>
          ) : (
            <div className="text-amber-100">
              <p>Aguardando terceiro colocado</p>
            </div>
          )}
        </div>
      </div>

      {/* Podium Visualization */}
      <PodiumCard ranking={ranking} />

      {/* Detailed Ranking Table */}
      <RankingTable ranking={ranking} showValues={!activeCampaign?.hideValues} />
    </div>
  );
};