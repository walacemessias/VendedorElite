import React from 'react';
import { StatsCards } from '../components/Dashboard/StatsCards';
import { PodiumCard } from '../components/Dashboard/PodiumCard';
import { RankingTable } from '../components/Dashboard/RankingTable';
import { SalesForm } from '../components/Sales/SalesForm';
import { useApp } from '../context/AppContext';

export const Dashboard: React.FC = () => {
  const { ranking, activeCampaign } = useApp();

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {activeCampaign?.name || 'Visão geral do sistema'} • 
            {ranking.length} vendedores ativos
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <StatsCards />

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Podium */}
        <PodiumCard ranking={ranking} />

        {/* Quick Actions */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
            🚀 Ações Rápidas
          </h3>
          <div className="space-y-3">
            <button className="w-full text-left p-4 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
              <div className="font-medium text-gray-900 dark:text-white">📝 Lançar Venda</div>
              <div className="text-sm text-gray-500 dark:text-gray-400">Adicionar nova venda ao sistema</div>
            </button>
            
            <button className="w-full text-left p-4 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-green-400 dark:hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors">
              <div className="font-medium text-gray-900 dark:text-white">🎯 Gerenciar Metas</div>
              <div className="text-sm text-gray-500 dark:text-gray-400">Configurar metas dos vendedores</div>
            </button>
            
            <button className="w-full text-left p-4 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-purple-400 dark:hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-colors">
              <div className="font-medium text-gray-900 dark:text-white">📺 Modo TV</div>
              <div className="text-sm text-gray-500 dark:text-gray-400">Ativar visualização para TV</div>
            </button>
          </div>
        </div>
      </div>

      {/* Full Ranking */}
      <RankingTable ranking={ranking} showValues={!activeCampaign?.hideValues} />

      {/* Sales Form */}
      <SalesForm />
    </div>
  );
};