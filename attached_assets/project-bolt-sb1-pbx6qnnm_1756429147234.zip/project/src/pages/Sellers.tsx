import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Users, Plus, Edit, Mail, Phone, Target, Camera } from 'lucide-react';
import { User, UserRole } from '../types';

interface SellerFormData {
  name: string;
  email: string;
  cpf: string;
  phone: string;
  photo: string;
  role: UserRole;
  teams: string[];
  password: string;
  target: number;
}

export const Sellers: React.FC = () => {
  const { teams, ranking } = useApp();
  const { hasPermission } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [editingSeller, setEditingSeller] = useState<User | null>(null);
  const [sellers, setSellers] = useState<User[]>([
    {
      id: '1',
      email: 'joao@empresa.com',
      name: 'João Silva',
      cpf: '12345678901',
      photo: 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      role: 'seller_with_edit',
      teams: ['team-1'],
      createdAt: new Date(),
      isActive: true
    },
    {
      id: '2',
      email: 'maria@empresa.com',
      name: 'Maria Santos',
      cpf: '98765432109',
      photo: 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      role: 'seller_with_edit',
      teams: ['team-1'],
      createdAt: new Date(),
      isActive: true
    },
    {
      id: '3',
      email: 'ana@empresa.com',
      name: 'Ana Oliveira',
      cpf: '11122233344',
      photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      role: 'seller_without_edit',
      teams: ['team-1'],
      createdAt: new Date(),
      isActive: true
    }
  ]);

  const [formData, setFormData] = useState<SellerFormData>({
    name: '',
    email: '',
    cpf: '',
    phone: '',
    photo: '',
    role: 'seller_with_edit',
    teams: [],
    password: '',
    target: 0
  });

  const canManageSellers = hasPermission('manage') || hasPermission('all');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newSeller: User = {
      id: editingSeller?.id || `seller-${Date.now()}`,
      email: formData.email,
      name: formData.name,
      cpf: formData.cpf.replace(/\D/g, ''),
      photo: formData.photo,
      role: formData.role,
      teams: formData.teams,
      createdAt: editingSeller?.createdAt || new Date(),
      isActive: true
    };

    if (editingSeller) {
      setSellers(prev => prev.map(s => s.id === editingSeller.id ? newSeller : s));
    } else {
      setSellers(prev => [...prev, newSeller]);
    }

    resetForm();
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      cpf: '',
      phone: '',
      photo: '',
      role: 'seller_with_edit',
      teams: [],
      password: '',
      target: 0
    });
    setShowForm(false);
    setEditingSeller(null);
  };

  const formatCPF = (cpf: string) => {
    const numbers = cpf.replace(/\D/g, '');
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  };

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    if (value.length <= 11) {
      setFormData(prev => ({ ...prev, cpf: value }));
    }
  };

  const getRoleLabel = (role: UserRole) => {
    const labels = {
      admin_with_visibility: 'Admin com Visualização',
      admin_without_visibility: 'Admin sem Visualização',
      seller_with_edit: 'Vendedor com Edição',
      seller_without_edit: 'Vendedor sem Edição',
      viewer: 'Visualizador'
    };
    return labels[role];
  };

  const getSellerStats = (sellerId: string) => {
    const stats = ranking.find(r => r.sellerId === sellerId);
    return stats || { position: 0, value: 0, target: 0, achievement: 0 };
  };

  const toggleSellerStatus = (sellerId: string) => {
    setSellers(prev => prev.map(s => 
      s.id === sellerId ? { ...s, isActive: !s.isActive } : s
    ));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <Users className="w-8 h-8 mr-3 text-blue-500" />
            Vendedores
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Gerencie vendedores e suas configurações
          </p>
        </div>
        
        {canManageSellers && (
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Vendedor</span>
          </button>
        )}
      </div>

      {/* Sellers Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Vendedor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Contato
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Perfil
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Performance
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {sellers.map((seller) => {
                const stats = getSellerStats(seller.id);
                return (
                  <tr key={seller.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <img
                            src={seller.photo || 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&dpr=2'}
                            alt={seller.name}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                          {!seller.isActive && (
                            <div className="absolute inset-0 bg-gray-500 bg-opacity-50 rounded-full flex items-center justify-center">
                              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {seller.name}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            CPF: {formatCPF(seller.cpf)}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900 dark:text-white">
                        <div className="flex items-center">
                          <Mail className="w-4 h-4 mr-1 text-gray-400" />
                          {seller.email}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm">
                        <div className="text-gray-900 dark:text-white font-medium">
                          {getRoleLabel(seller.role)}
                        </div>
                        <div className="text-gray-500 dark:text-gray-400">
                          {seller.teams.length} time(s)
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {stats.position > 0 ? (
                        <div className="text-sm">
                          <div className="text-gray-900 dark:text-white font-medium">
                            #{stats.position} • {stats.achievement}%
                          </div>
                          <div className="text-gray-500 dark:text-gray-400">
                            R$ {stats.value.toLocaleString('pt-BR')} / R$ {stats.target.toLocaleString('pt-BR')}
                          </div>
                        </div>
                      ) : (
                        <span className="text-gray-400 text-sm">Sem dados</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => toggleSellerStatus(seller.id)}
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          seller.isActive
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                            : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                        }`}
                      >
                        {seller.isActive ? 'Ativo' : 'Inativo'}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {canManageSellers && (
                        <button
                          onClick={() => {
                            setEditingSeller(seller);
                            setFormData({
                              name: seller.name,
                              email: seller.email,
                              cpf: seller.cpf,
                              phone: '',
                              photo: seller.photo || '',
                              role: seller.role,
                              teams: seller.teams,
                              password: '',
                              target: stats.target
                            });
                            setShowForm(true);
                          }}
                          className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create/Edit Seller Form */}
      {showForm && canManageSellers && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingSeller ? 'Editar Vendedor' : 'Novo Vendedor'}
              </h3>
              <button
                onClick={resetForm}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Photo Upload */}
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img
                    src={formData.photo || 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&dpr=2'}
                    alt="Preview"
                    className="w-20 h-20 rounded-full object-cover border-4 border-gray-200 dark:border-gray-600"
                  />
                  <button
                    type="button"
                    className="absolute bottom-0 right-0 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white hover:bg-blue-600 transition-colors"
                  >
                    <Camera className="w-3 h-3" />
                  </button>
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    URL da Foto
                  </label>
                  <input
                    type="url"
                    value={formData.photo}
                    onChange={(e) => setFormData(prev => ({ ...prev, photo: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="https://exemplo.com/foto.jpg"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="Digite o nome completo"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="email@empresa.com"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    CPF (apenas números) *
                  </label>
                  <input
                    type="text"
                    value={formatCPF(formData.cpf)}
                    onChange={handleCPFChange}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="000.000.000-00"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="(11) 99999-9999"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Perfil de Acesso
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value as UserRole }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  >
                    <option value="seller_with_edit">Vendedor com Edição</option>
                    <option value="seller_without_edit">Vendedor sem Edição</option>
                    <option value="admin_with_visibility">Admin com Visualização</option>
                    <option value="admin_without_visibility">Admin sem Visualização</option>
                    <option value="viewer">Visualizador</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Meta Atual (R$)
                  </label>
                  <input
                    type="number"
                    value={formData.target}
                    onChange={(e) => setFormData(prev => ({ ...prev, target: parseFloat(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="0"
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Times
                </label>
                <div className="space-y-2">
                  {teams.map((team) => (
                    <label key={team.id} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.teams.includes(team.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setFormData(prev => ({ ...prev, teams: [...prev.teams, team.id] }));
                          } else {
                            setFormData(prev => ({ ...prev, teams: prev.teams.filter(t => t !== team.id) }));
                          }
                        }}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                        {team.name}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {!editingSeller && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Senha Inicial *
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="Mínimo 6 caracteres"
                    minLength={6}
                    required
                  />
                </div>
              )}

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                >
                  {editingSeller ? 'Atualizar Vendedor' : 'Criar Vendedor'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};