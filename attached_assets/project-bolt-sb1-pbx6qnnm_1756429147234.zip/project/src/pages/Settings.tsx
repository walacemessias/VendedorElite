import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Settings as SettingsIcon, Volume2, VolumeX, Upload, Palette, Bell, Shield, Globe } from 'lucide-react';

export const Settings: React.FC = () => {
  const { settings, updateSettings } = useApp();
  const { hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState('general');

  const canConfigureSettings = hasPermission('configure') || hasPermission('all');

  const soundOptions = {
    sale: [
      { id: 'money', name: 'Dinheiro', description: 'Som de moedas' },
      { id: 'applause', name: 'Aplausos', description: 'Som de palmas' },
      { id: 'f1', name: 'Fórmula 1', description: 'Som de motor de F1' },
      { id: 'horn', name: 'Buzina', description: 'Som de buzina' },
      { id: 'crowd', name: 'Torcida', description: 'Som de torcida' }
    ],
    positionChange: [
      { id: 'racing', name: 'Corrida', description: 'Som de ultrapassagem' },
      { id: 'whoosh', name: 'Whoosh', description: 'Som de movimento rápido' },
      { id: 'notification', name: 'Notificação', description: 'Som de alerta' }
    ],
    podiumEntry: [
      { id: 'achievement', name: 'Conquista', description: 'Som de conquista' },
      { id: 'fanfare', name: 'Fanfarra', description: 'Som de fanfarra' },
      { id: 'victory', name: 'Vitória', description: 'Som de vitória' }
    ],
    firstPlace: [
      { id: 'victory', name: 'Vitória', description: 'Som de vitória épica' },
      { id: 'champion', name: 'Campeão', description: 'Som de campeão' },
      { id: 'celebration', name: 'Celebração', description: 'Som de celebração' }
    ]
  };

  const tabs = [
    { id: 'general', name: 'Geral', icon: SettingsIcon },
    { id: 'sounds', name: 'Sons', icon: Volume2 },
    { id: 'appearance', name: 'Aparência', icon: Palette },
    { id: 'notifications', name: 'Notificações', icon: Bell },
    { id: 'security', name: 'Segurança', icon: Shield },
    { id: 'integrations', name: 'Integrações', icon: Globe }
  ];

  if (!canConfigureSettings) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Acesso Negado
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Você não tem permissão para acessar as configurações.
          </p>
        </div>
      </div>
    );
  }

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Configurações Gerais
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Logo da Empresa
            </label>
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                {settings.companyLogo ? (
                  <img src={settings.companyLogo} alt="Logo" className="w-full h-full object-contain rounded-lg" />
                ) : (
                  <Upload className="w-6 h-6 text-gray-400" />
                )}
              </div>
              <div className="flex-1">
                <input
                  type="url"
                  placeholder="URL da logo da empresa"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  value={settings.companyLogo || ''}
                  onChange={(e) => updateSettings({ companyLogo: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Configurações de Sistema
            </label>
            <div className="space-y-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.soundsEnabled}
                  onChange={(e) => updateSettings({ soundsEnabled: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                  Habilitar sons globalmente
                </span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSoundSettings = () => (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Configurações de Som
          </h3>
          <button
            onClick={() => updateSettings({ soundsEnabled: !settings.soundsEnabled })}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
              settings.soundsEnabled
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
            }`}
          >
            {settings.soundsEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span>{settings.soundsEnabled ? 'Sons Ativos' : 'Sons Desativados'}</span>
          </button>
        </div>

        <div className="space-y-6">
          {/* Sale Sounds */}
          <div>
            <h4 className="font-medium text-gray-900 dark:text-white mb-3">
              Sons de Venda (múltiplos permitidos)
            </h4>
            <div className="grid md:grid-cols-2 gap-3">
              {soundOptions.sale.map((sound) => (
                <label key={sound.id} className="flex items-center p-3 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.selectedSounds.sale.includes(sound.id)}
                    onChange={(e) => {
                      const currentSounds = settings.selectedSounds.sale;
                      const newSounds = e.target.checked
                        ? [...currentSounds, sound.id]
                        : currentSounds.filter(s => s !== sound.id);
                      updateSettings({
                        selectedSounds: { ...settings.selectedSounds, sale: newSounds }
                      });
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <div className="ml-3">
                    <div className="font-medium text-gray-900 dark:text-white">{sound.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{sound.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Position Change Sounds */}
          <div>
            <h4 className="font-medium text-gray-900 dark:text-white mb-3">
              Som de Ultrapassagem
            </h4>
            <div className="grid md:grid-cols-2 gap-3">
              {soundOptions.positionChange.map((sound) => (
                <label key={sound.id} className="flex items-center p-3 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                  <input
                    type="radio"
                    name="positionChange"
                    checked={settings.selectedSounds.positionChange === sound.id}
                    onChange={() => updateSettings({
                      selectedSounds: { ...settings.selectedSounds, positionChange: sound.id }
                    })}
                    className="border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <div className="ml-3">
                    <div className="font-medium text-gray-900 dark:text-white">{sound.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{sound.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Podium Entry Sounds */}
          <div>
            <h4 className="font-medium text-gray-900 dark:text-white mb-3">
              Som de Entrada no Pódio
            </h4>
            <div className="grid md:grid-cols-2 gap-3">
              {soundOptions.podiumEntry.map((sound) => (
                <label key={sound.id} className="flex items-center p-3 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                  <input
                    type="radio"
                    name="podiumEntry"
                    checked={settings.selectedSounds.podiumEntry === sound.id}
                    onChange={() => updateSettings({
                      selectedSounds: { ...settings.selectedSounds, podiumEntry: sound.id }
                    })}
                    className="border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <div className="ml-3">
                    <div className="font-medium text-gray-900 dark:text-white">{sound.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{sound.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* First Place Sounds */}
          <div>
            <h4 className="font-medium text-gray-900 dark:text-white mb-3">
              Som de Primeiro Lugar
            </h4>
            <div className="grid md:grid-cols-2 gap-3">
              {soundOptions.firstPlace.map((sound) => (
                <label key={sound.id} className="flex items-center p-3 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                  <input
                    type="radio"
                    name="firstPlace"
                    checked={settings.selectedSounds.firstPlace === sound.id}
                    onChange={() => updateSettings({
                      selectedSounds: { ...settings.selectedSounds, firstPlace: sound.id }
                    })}
                    className="border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <div className="ml-3">
                    <div className="font-medium text-gray-900 dark:text-white">{sound.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{sound.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAppearanceSettings = () => (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Configurações de Aparência
        </h3>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Tema do Sistema
            </label>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => updateSettings({ theme: 'light' })}
                className={`p-4 border-2 rounded-lg transition-colors ${
                  settings.theme === 'light'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                }`}
              >
                <div className="w-full h-20 bg-white border border-gray-200 rounded mb-2"></div>
                <span className="font-medium text-gray-900 dark:text-white">Tema Claro</span>
              </button>
              
              <button
                onClick={() => updateSettings({ theme: 'dark' })}
                className={`p-4 border-2 rounded-lg transition-colors ${
                  settings.theme === 'dark'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                }`}
              >
                <div className="w-full h-20 bg-gray-800 border border-gray-600 rounded mb-2"></div>
                <span className="font-medium text-gray-900 dark:text-white">Tema Escuro</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Temas Disponíveis (Em Desenvolvimento)
            </label>
            <div className="grid grid-cols-3 gap-4 opacity-50">
              <div className="p-4 border-2 border-gray-200 dark:border-gray-600 rounded-lg">
                <div className="w-full h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded mb-2"></div>
                <span className="font-medium text-gray-900 dark:text-white">Game</span>
              </div>
              
              <div className="p-4 border-2 border-gray-200 dark:border-gray-600 rounded-lg">
                <div className="w-full h-20 bg-white border border-gray-200 rounded mb-2"></div>
                <span className="font-medium text-gray-900 dark:text-white">Branco</span>
              </div>
              
              <div className="p-4 border-2 border-gray-200 dark:border-gray-600 rounded-lg">
                <div className="w-full h-20 bg-black rounded mb-2"></div>
                <span className="font-medium text-gray-900 dark:text-white">Black</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderPlaceholderTab = (title: string, description: string) => (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-12 text-center">
        <SettingsIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
          {title}
        </h3>
        <p className="text-gray-600 dark:text-gray-400">
          {description}
        </p>
      </div>
    </div>
  );

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'general':
        return renderGeneralSettings();
      case 'sounds':
        return renderSoundSettings();
      case 'appearance':
        return renderAppearanceSettings();
      case 'notifications':
        return renderPlaceholderTab('Notificações', 'Configurações de notificações em desenvolvimento');
      case 'security':
        return renderPlaceholderTab('Segurança', 'Configurações de segurança em desenvolvimento');
      case 'integrations':
        return renderPlaceholderTab('Integrações', 'API/Webhook e integrações em desenvolvimento');
      default:
        return renderGeneralSettings();
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <SettingsIcon className="w-8 h-8 mr-3 text-gray-500" />
            Configurações
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Configure o sistema de acordo com suas necessidades
          </p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Settings Navigation */}
        <div className="lg:w-64">
          <nav className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
            <ul className="space-y-2">
              {tabs.map((tab) => (
                <li key={tab.id}>
                  <button
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span className="font-medium">{tab.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        {/* Settings Content */}
        <div className="flex-1">
          {renderActiveTab()}
        </div>
      </div>
    </div>
  );
};