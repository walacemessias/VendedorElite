import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Award, Plus, Edit, Eye, EyeOff, Trophy, Medal, Star } from 'lucide-react';
import { Prize } from '../types';

export const Prizes: React.FC = () => {
  const { campaigns, activeCampaign } = useApp();
  const { hasPermission } = useAuth();
  const [selectedCampaign, setSelectedCampaign] = useState(activeCampaign?.id || '');
  const [showForm, setShowForm] = useState(false);
  const [editingPrize, setEditingPrize] = useState<Prize | null>(null);
  const [formData, setFormData] = useState({
    position: 1,
    name: '',
    description: '',
    icon: '🏆',
    visible: true
  });

  const canManagePrizes = hasPermission('manage') || hasPermission('all');

  const currentCampaign = campaigns.find(c => c.id === selectedCampaign);
  const prizes = currentCampaign?.prizes || [];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would update the campaign's prizes
    console.log('Prize data:', formData);
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      position: 1,
      name: '',
      description: '',
      icon: '🏆',
      visible: true
    });
    setShowForm(false);
    setEditingPrize(null);
  };

  const getPositionIcon = (position: number) => {
    switch (position) {
      case 1: return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 2: return <Medal className="w-6 h-6 text-gray-400" />;
      case 3: return <Award className="w-6 h-6 text-amber-600" />;
      default: return <Star className="w-6 h-6 text-blue-500" />;
    }
  };

  const getPositionColor = (position: number) => {
    switch (position) {
      case 1: return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
      case 2: return 'bg-gradient-to-r from-gray-400 to-gray-600';
      case 3: return 'bg-gradient-to-r from-amber-600 to-amber-800';
      default: return 'bg-gradient-to-r from-blue-500 to-blue-600';
    }
  };

  const iconOptions = [
    '🏆', '🥇', '🎖️', '🏅', '👑', '💎', '⭐', '🌟', 
    '🎁', '🎉', '🎊', '💰', '💵', '🚗', '✈️', '🏖️',
    '📱', '💻', '⌚', '🎧', '📷', '🎮', '🏠', '🌴'
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <Award className="w-8 h-8 mr-3 text-yellow-500" />
            Premiações
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Configure prêmios e recompensas por campanha
          </p>
        </div>
        
        {canManagePrizes && currentCampaign && (
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Prêmio</span>
          </button>
        )}
      </div>

      {/* Campaign Selection */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center space-x-4">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Selecionar Campanha:
          </label>
          <select
            value={selectedCampaign}
            onChange={(e) => setSelectedCampaign(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="">Selecione uma campanha</option>
            {campaigns.map((campaign) => (
              <option key={campaign.id} value={campaign.id}>
                {campaign.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {currentCampaign ? (
        <>
          {/* Campaign Info */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {currentCampaign.name}
            </h3>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-gray-600 dark:text-gray-400">Período:</span>
                <span className="ml-2 text-gray-900 dark:text-white font-medium">
                  {currentCampaign.startDate.toLocaleDateString('pt-BR')} - {currentCampaign.endDate.toLocaleDateString('pt-BR')}
                </span>
              </div>
              <div>
                <span className="text-gray-600 dark:text-gray-400">Status:</span>
                <span className="ml-2 text-gray-900 dark:text-white font-medium">
                  {currentCampaign.isActive ? 'Ativa' : 'Inativa'}
                </span>
              </div>
              <div>
                <span className="text-gray-600 dark:text-gray-400">Prêmios:</span>
                <span className="ml-2 text-gray-900 dark:text-white font-medium">
                  {prizes.filter(p => p.visible).length} visíveis de {prizes.length} total
                </span>
              </div>
            </div>
          </div>

          {/* Prizes Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {prizes.map((prize) => (
              <div
                key={prize.id}
                className={`rounded-xl shadow-sm border-2 transition-all ${
                  prize.visible 
                    ? 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800' 
                    : 'border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 opacity-75'
                }`}
              >
                <div className={`${getPositionColor(prize.position)} p-4 rounded-t-xl`}>
                  <div className="flex items-center justify-between text-white">
                    <div className="flex items-center space-x-2">
                      {getPositionIcon(prize.position)}
                      <span className="font-bold text-lg">{prize.position}º Lugar</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {prize.visible ? (
                        <Eye className="w-4 h-4" />
                      ) : (
                        <EyeOff className="w-4 h-4" />
                      )}
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-2">{prize.icon}</div>
                    <h3 className="font-bold text-lg text-gray-900 dark:text-white">
                      {prize.name}
                    </h3>
                  </div>

                  <p className="text-gray-600 dark:text-gray-400 text-sm text-center mb-4">
                    {prize.description}
                  </p>

                  <div className="flex items-center justify-between">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      prize.visible 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
                    }`}>
                      {prize.visible ? 'Visível' : 'Oculto'}
                    </span>

                    {canManagePrizes && (
                      <button
                        onClick={() => {
                          setEditingPrize(prize);
                          setFormData({
                            position: prize.position,
                            name: prize.name,
                            description: prize.description,
                            icon: prize.icon,
                            visible: prize.visible
                          });
                          setShowForm(true);
                        }}
                        className="p-2 text-gray-400 hover:text-blue-500 transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* Add Prize Card */}
            {canManagePrizes && prizes.length < 10 && (
              <div
                onClick={() => setShowForm(true)}
                className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-yellow-400 dark:hover:border-yellow-500 hover:bg-yellow-50 dark:hover:bg-yellow-900/20 transition-colors min-h-[280px]"
              >
                <Plus className="w-12 h-12 text-gray-400 mb-4" />
                <span className="text-gray-600 dark:text-gray-400 font-medium">
                  Adicionar Prêmio
                </span>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-12 text-center">
          <Award className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Selecione uma Campanha
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Escolha uma campanha para visualizar e gerenciar suas premiações
          </p>
        </div>
      )}

      {/* Create/Edit Prize Form */}
      {showForm && canManagePrizes && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingPrize ? 'Editar Prêmio' : 'Novo Prêmio'}
              </h3>
              <button
                onClick={resetForm}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Posição
                </label>
                <select
                  value={formData.position}
                  onChange={(e) => setFormData(prev => ({ ...prev, position: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  required
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(pos => (
                    <option key={pos} value={pos}>{pos}º Lugar</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Nome do Prêmio
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="Ex: Viagem para Europa"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Descrição
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  rows={3}
                  placeholder="Descreva o prêmio em detalhes"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Ícone do Prêmio
                </label>
                <div className="grid grid-cols-8 gap-2 mb-3">
                  {iconOptions.map((icon) => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, icon }))}
                      className={`p-2 text-2xl rounded-lg border-2 transition-colors ${
                        formData.icon === icon
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={formData.icon}
                  onChange={(e) => setFormData(prev => ({ ...prev, icon: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="Ou digite um emoji personalizado"
                />
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="visible"
                  checked={formData.visible}
                  onChange={(e) => setFormData(prev => ({ ...prev, visible: e.target.checked }))}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="visible" className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                  Prêmio visível no ranking
                </label>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg transition-colors"
                >
                  {editingPrize ? 'Atualizar Prêmio' : 'Criar Prêmio'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};