// User and Authentication Types
export interface User {
  id: string;
  email: string;
  name: string;
  cpf: string;
  photo?: string;
  role: UserRole;
  teams: string[];
  createdAt: Date;
  isActive: boolean;
}

export type UserRole = 
  | 'admin_with_visibility' 
  | 'admin_without_visibility' 
  | 'seller_with_edit' 
  | 'seller_without_edit' 
  | 'viewer';

export interface LoginCredentials {
  email: string;
  password: string;
}

// Team Types
export interface Team {
  id: string;
  name: string;
  logo?: string;
  scoringType: 'units' | 'monetary_value';
  displayType: 'volume' | 'percentage';
  isDefault: boolean;
  createdAt: Date;
  campaignId?: string;
}

// Campaign Types
export interface Campaign {
  id: string;
  name: string;
  teamId: string;
  period: CampaignPeriod;
  startDate: Date;
  endDate: Date;
  autoReset: boolean;
  hideValues: boolean;
  prizes: Prize[];
  targets: SellerTarget[];
  isActive: boolean;
  createdAt: Date;
}

export type CampaignPeriod = 'monthly' | 'bimonthly' | 'quarterly' | 'semiannual' | 'custom';

export interface Prize {
  id: string;
  position: number; // 1st, 2nd, 3rd
  name: string;
  description: string;
  icon: string;
  visible: boolean;
}

export interface SellerTarget {
  sellerId: string;
  target: number;
  currentTotal: number;
  achievement: number; // percentage
}

// Sales Types
export interface Sale {
  id: string;
  sellerId: string;
  teamId: string;
  campaignId: string;
  value: number;
  quantity: number;
  points: number;
  timestamp: Date;
}

// Ranking Types
export interface RankingEntry {
  sellerId: string;
  sellerName: string;
  sellerPhoto?: string;
  position: number;
  previousPosition: number;
  value: number;
  target: number;
  achievement: number;
  prizes: Prize[];
}

// Notification Types
export interface Notification {
  id: string;
  type: 'sale' | 'position_change' | 'podium_entry' | 'first_place';
  sellerId: string;
  sellerName: string;
  message: string;
  timestamp: Date;
  soundEnabled: boolean;
}

// Theme and Settings Types
export interface AppSettings {
  theme: 'light' | 'dark';
  companyLogo?: string;
  soundsEnabled: boolean;
  selectedSounds: {
    sale: string[];
    positionChange: string;
    podiumEntry: string;
    firstPlace: string;
  };
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}