import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { AppProvider } from './context/AppContext';
import { Header } from './components/Layout/Header';
import { Sidebar } from './components/Layout/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { Teams } from './pages/Teams';
import { Ranking } from './pages/Ranking';
import { Campaigns } from './pages/Campaigns';
import { Sellers } from './pages/Sellers';
import { Prizes } from './pages/Prizes';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';
import { TVMode } from './components/TVMode/TVMode';
import { NotificationToast } from './components/Notifications/NotificationToast';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showSettings, setShowSettings] = useState(false);
  const [showTvMode, setShowTvMode] = useState(false);

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'teams':
        return <Teams />;
      case 'ranking':
        return <Ranking />;
      case 'campaigns':
        return <Campaigns />;
      case 'sellers':
        return <Sellers />;
      case 'prizes':
        return <Prizes />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <AuthProvider>
      <AppProvider>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
          {/* TV Mode */}
          {showTvMode && <TVMode onClose={() => setShowTvMode(false)} />}
          
          {/* Main Layout */}
          {!showTvMode && (
            <div className="flex h-screen">
              {/* Sidebar */}
              <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
              
              {/* Main Content */}
              <div className="flex-1 flex flex-col overflow-hidden">
                <Header 
                  onOpenSettings={() => setShowSettings(true)} 
                  onOpenTvMode={() => setShowTvMode(true)}
                />
                <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900">
                  {renderActiveTab()}
                </main>
              </div>
            </div>
          )}

          {/* Global Components */}
          <NotificationToast />
        </div>
      </AppProvider>
    </AuthProvider>
  );
}

export default App;