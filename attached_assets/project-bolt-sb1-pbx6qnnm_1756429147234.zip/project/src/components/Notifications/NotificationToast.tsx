import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { DollarSign, TrendingUp, Trophy, Star } from 'lucide-react';

export const NotificationToast: React.FC = () => {
  const { notifications, settings } = useApp();

  useEffect(() => {
    // Play sound when new notification arrives
    if (notifications.length > 0 && settings.soundsEnabled) {
      const notification = notifications[0];
      if (notification.soundEnabled) {
        // In a real app, you would play actual sound files here
        console.log(`Playing sound for ${notification.type}`);
      }
    }
  }, [notifications, settings.soundsEnabled]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'sale': return <DollarSign className="w-5 h-5 text-green-500" />;
      case 'position_change': return <TrendingUp className="w-5 h-5 text-blue-500" />;
      case 'podium_entry': return <Trophy className="w-5 h-5 text-yellow-500" />;
      case 'first_place': return <Star className="w-5 h-5 text-purple-500" />;
      default: return <DollarSign className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'sale': return 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20';
      case 'position_change': return 'border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-900/20';
      case 'podium_entry': return 'border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-900/20';
      case 'first_place': return 'border-purple-200 bg-purple-50 dark:border-purple-800 dark:bg-purple-900/20';
      default: return 'border-gray-200 bg-gray-50 dark:border-gray-700 dark:bg-gray-800';
    }
  };

  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-6 left-6 space-y-2 z-40">
      {notifications.slice(0, 3).map((notification) => (
        <div
          key={notification.id}
          className={`
            flex items-center space-x-3 p-4 rounded-lg shadow-lg border-2
            ${getNotificationColor(notification.type)}
            transform transition-all duration-500 ease-out
            animate-slide-up
          `}
        >
          {getNotificationIcon(notification.type)}
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-900 dark:text-white">
              {notification.message}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {notification.timestamp.toLocaleTimeString('pt-BR')}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};