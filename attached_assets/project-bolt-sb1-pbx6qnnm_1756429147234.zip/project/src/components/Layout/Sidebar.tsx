import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Users, 
  Trophy, 
  Target, 
  BarChart3, 
  Settings, 
  Shield,
  Home,
  Award
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const { hasPermission } = useAuth();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home, permission: 'view' },
    { id: 'teams', label: 'Times', icon: Shield, permission: 'manage' },
    { id: 'campaigns', label: 'Campanhas', icon: Target, permission: 'manage' },
    { id: 'sellers', label: 'Vendedores', icon: Users, permission: 'manage' },
    { id: 'ranking', label: 'Ranking', icon: Trophy, permission: 'view' },
    { id: 'prizes', label: 'Premiações', icon: Award, permission: 'manage' },
    { id: 'reports', label: 'Relatórios', icon: BarChart3, permission: 'view' },
    { id: 'settings', label: 'Configurações', icon: Settings, permission: 'configure' }
  ];

  const availableItems = menuItems.filter(item => hasPermission(item.permission) || hasPermission('all'));

  return (
    <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 h-full">
      <nav className="p-4">
        <ul className="space-y-2">
          {availableItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                  activeTab === item.id
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};