import React from 'react';
import { useApp } from '../../context/AppContext';
import { TrendingUp, Target, Users, Award } from 'lucide-react';

export const StatsCards: React.FC = () => {
  const { ranking, activeCampaign } = useApp();

  const totalSales = ranking.reduce((sum, entry) => sum + entry.value, 0);
  const totalTarget = ranking.reduce((sum, entry) => sum + entry.target, 0);
  const averageAchievement = ranking.reduce((sum, entry) => sum + entry.achievement, 0) / ranking.length;
  const sellersInPodium = ranking.filter(entry => entry.position <= 3).length;

  const stats = [
    {
      title: 'Vendas Totais',
      value: `R$ ${totalSales.toLocaleString('pt-BR')}`,
      change: '+12.5%',
      changeType: 'positive' as const,
      icon: TrendingUp,
      color: 'blue'
    },
    {
      title: 'Meta Total',
      value: `R$ ${totalTarget.toLocaleString('pt-BR')}`,
      change: `${Math.round((totalSales / totalTarget) * 100)}% atingido`,
      changeType: totalSales >= totalTarget ? 'positive' as const : 'neutral' as const,
      icon: Target,
      color: 'green'
    },
    {
      title: 'Vendedores Ativos',
      value: ranking.length.toString(),
      change: `${sellersInPodium} no pódio`,
      changeType: 'neutral' as const,
      icon: Users,
      color: 'purple'
    },
    {
      title: 'Média de Atingimento',
      value: `${Math.round(averageAchievement)}%`,
      change: activeCampaign?.name || 'Campanha Ativa',
      changeType: averageAchievement >= 80 ? 'positive' as const : 'neutral' as const,
      icon: Award,
      color: 'orange'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-500',
      green: 'bg-green-500',
      purple: 'bg-purple-500',
      orange: 'bg-orange-500'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const getChangeColorClasses = (type: 'positive' | 'negative' | 'neutral') => {
    switch (type) {
      case 'positive':
        return 'text-green-600 dark:text-green-400';
      case 'negative':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <div
          key={index}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                {stat.title}
              </p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {stat.value}
              </p>
              <p className={`text-sm mt-2 ${getChangeColorClasses(stat.changeType)}`}>
                {stat.change}
              </p>
            </div>
            <div className={`w-12 h-12 ${getColorClasses(stat.color)} rounded-lg flex items-center justify-center`}>
              <stat.icon className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};