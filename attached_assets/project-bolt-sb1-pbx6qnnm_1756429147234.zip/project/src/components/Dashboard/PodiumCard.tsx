import React from 'react';
import { RankingEntry } from '../../types';
import { Trophy, Medal, Award } from 'lucide-react';

interface PodiumCardProps {
  ranking: RankingEntry[];
}

export const PodiumCard: React.FC<PodiumCardProps> = ({ ranking }) => {
  const podiumEntries = ranking.slice(0, 3);

  const getPodiumIcon = (position: number) => {
    switch (position) {
      case 1: return <Trophy className="w-8 h-8 text-yellow-500" />;
      case 2: return <Medal className="w-8 h-8 text-gray-400" />;
      case 3: return <Award className="w-8 h-8 text-amber-600" />;
      default: return null;
    }
  };

  const getPodiumHeight = (position: number) => {
    switch (position) {
      case 1: return 'h-32';
      case 2: return 'h-24';
      case 3: return 'h-20';
      default: return 'h-16';
    }
  };

  const getPodiumBg = (position: number) => {
    switch (position) {
      case 1: return 'bg-gradient-to-t from-yellow-400 to-yellow-300';
      case 2: return 'bg-gradient-to-t from-gray-400 to-gray-300';
      case 3: return 'bg-gradient-to-t from-amber-600 to-amber-500';
      default: return 'bg-gray-200';
    }
  };

  const reorderedEntries = [
    podiumEntries[1], // 2nd place (left)
    podiumEntries[0], // 1st place (center)
    podiumEntries[2]  // 3rd place (right)
  ].filter(Boolean);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 text-center">
        🏆 Pódio da Campanha
      </h3>

      <div className="flex items-end justify-center space-x-4">
        {reorderedEntries.map((entry, index) => {
          if (!entry) return null;
          
          const originalPosition = entry.position;
          const displayOrder = [2, 1, 3][index];
          
          return (
            <div key={entry.sellerId} className="flex flex-col items-center">
              {/* Seller Info */}
              <div className="mb-4 text-center">
                <div className="relative mb-3">
                  <img
                    src={entry.sellerPhoto || 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&dpr=2'}
                    alt={entry.sellerName}
                    className="w-16 h-16 rounded-full object-cover mx-auto border-4 border-white dark:border-gray-700 shadow-lg"
                  />
                  <div className="absolute -top-2 -right-2">
                    {getPodiumIcon(originalPosition)}
                  </div>
                </div>
                <h4 className="font-semibold text-gray-900 dark:text-white text-sm">
                  {entry.sellerName}
                </h4>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {entry.achievement}% da meta
                </p>
              </div>

              {/* Podium Block */}
              <div className={`
                w-20 ${getPodiumHeight(originalPosition)} ${getPodiumBg(originalPosition)} 
                rounded-t-lg flex items-end justify-center pb-3 relative
                shadow-lg transition-all duration-300 hover:scale-105
              `}>
                <span className="text-white font-bold text-2xl">
                  {originalPosition}
                </span>
                
                {/* Floating animation for 1st place */}
                {originalPosition === 1 && (
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                    <div className="animate-bounce">
                      <div className="w-2 h-2 bg-yellow-300 rounded-full"></div>
                    </div>
                  </div>
                )}
              </div>

              {/* Achievement Details */}
              <div className="mt-3 text-center">
                <p className="text-sm font-medium text-gray-900 dark:text-white">
                  R$ {entry.value.toLocaleString('pt-BR')}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Meta: R$ {entry.target.toLocaleString('pt-BR')}
                </p>
                {entry.prizes.length > 0 && (
                  <div className="mt-2">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200">
                      {entry.prizes[0].name}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Podium Base */}
      <div className="mt-4 h-4 bg-gradient-to-r from-gray-600 via-gray-500 to-gray-600 rounded-lg mx-8"></div>
    </div>
  );
};