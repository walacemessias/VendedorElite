import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { Plus, DollarSign } from 'lucide-react';

export const SalesForm: React.FC = () => {
  const { ranking, addSale, activeTeam, activeCampaign } = useApp();
  const { user, hasPermission } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    sellerId: user?.id || '',
    value: '',
    quantity: '1',
    points: ''
  });

  const canAddSales = hasPermission('edit_own_sales') || hasPermission('all');

  if (!canAddSales) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!activeTeam || !activeCampaign) {
      alert('Nenhum time ou campanha ativa encontrada');
      return;
    }

    const value = parseFloat(formData.value.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
    const quantity = parseInt(formData.quantity) || 1;
    const points = parseFloat(formData.points) || value;

    addSale({
      sellerId: formData.sellerId,
      teamId: activeTeam.id,
      campaignId: activeCampaign.id,
      value,
      quantity,
      points
    });

    // Reset form
    setFormData({
      sellerId: user?.id || '',
      value: '',
      quantity: '1',
      points: ''
    });
    
    setIsOpen(false);
  };

  const formatCurrency = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    const formatted = (parseFloat(numbers) / 100 || 0).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
    return formatted;
  };

  const handleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCurrency(e.target.value);
    setFormData(prev => ({ ...prev, value: formatted }));
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-500 hover:bg-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center z-50"
        title="Lançar Venda"
      >
        <Plus className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center">
            <DollarSign className="w-6 h-6 mr-2 text-green-500" />
            Lançar Venda
          </h3>
          <button
            onClick={() => setIsOpen(false)}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Vendedor
            </label>
            <select
              value={formData.sellerId}
              onChange={(e) => setFormData(prev => ({ ...prev, sellerId: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              required
            >
              <option value="">Selecione o vendedor</option>
              {ranking.map((entry) => (
                <option key={entry.sellerId} value={entry.sellerId}>
                  {entry.sellerName}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Valor da Venda
            </label>
            <input
              type="text"
              value={formData.value}
              onChange={handleValueChange}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              placeholder="R$ 0,00"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Quantidade
            </label>
            <input
              type="number"
              value={formData.quantity}
              onChange={(e) => setFormData(prev => ({ ...prev, quantity: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              min="1"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Pontos (opcional)
            </label>
            <input
              type="number"
              value={formData.points}
              onChange={(e) => setFormData(prev => ({ ...prev, points: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              placeholder="Deixe vazio para usar o valor"
              step="0.01"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
            >
              Lançar Venda
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};