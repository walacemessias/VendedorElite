import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X } from 'lucide-react';
import { RankingTable } from '../Dashboard/RankingTable';
import { PodiumCard } from '../Dashboard/PodiumCard';

interface TVModeProps {
  onClose: () => void;
}

export const TVMode: React.FC<TVModeProps> = ({ onClose }) => {
  const { ranking, activeCampaign, notifications } = useApp();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Hide cursor after 5 seconds of inactivity
    let timeout: NodeJS.Timeout;
    
    const resetTimeout = () => {
      clearTimeout(timeout);
      document.body.style.cursor = 'default';
      timeout = setTimeout(() => {
        document.body.style.cursor = 'none';
      }, 5000);
    };

    document.addEventListener('mousemove', resetTimeout);
    resetTimeout();

    return () => {
      document.removeEventListener('mousemove', resetTimeout);
      clearTimeout(timeout);
      document.body.style.cursor = 'default';
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-gray-900 text-white z-50 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-6 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center space-x-4">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            🏆 SalesGame TV
          </div>
          <div className="text-lg text-gray-300">
            {activeCampaign?.name || 'Campanha Ativa'}
          </div>
        </div>
        
        <div className="flex items-center space-x-6">
          <div className="text-right">
            <div className="text-2xl font-bold">
              {currentTime.toLocaleTimeString('pt-BR')}
            </div>
            <div className="text-sm text-gray-400">
              {currentTime.toLocaleDateString('pt-BR')}
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
            title="Fechar TV Mode"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="p-8 h-full overflow-y-auto">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Podium - Featured */}
          <div className="transform scale-110">
            <PodiumCard ranking={ranking} />
          </div>

          {/* Full Ranking */}
          <div className="mt-12">
            <RankingTable ranking={ranking} showValues={!activeCampaign?.hideValues} />
          </div>

          {/* Live Updates Info */}
          <div className="text-center text-gray-400 text-sm">
            <p>🔄 Atualizações em tempo real • 📺 Modo TV Ativo</p>
          </div>
        </div>
      </div>

      {/* TV Mode Notifications - Larger */}
      <div className="fixed bottom-8 left-8 space-y-3 z-60">
        {notifications.slice(0, 2).map((notification) => (
          <div
            key={notification.id}
            className="flex items-center space-x-4 p-6 rounded-xl shadow-2xl border-2
              bg-gray-800 border-blue-500 text-white transform transition-all duration-1000 
              animate-slide-up"
          >
            <div className="text-3xl">💰</div>
            <div className="flex-1">
              <p className="text-xl font-bold">
                {notification.message}
              </p>
              <p className="text-sm text-gray-300">
                {notification.timestamp.toLocaleTimeString('pt-BR')}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};