import React, { createContext, useContext, useState, useEffect } from 'react';
import { Team, Campaign, Sale, RankingEntry, AppSettings, Notification } from '../types';

interface AppContextType {
  // Settings
  settings: AppSettings;
  updateSettings: (settings: Partial<AppSettings>) => void;
  
  // Teams
  teams: Team[];
  activeTeam: Team | null;
  setActiveTeam: (team: Team) => void;
  createTeam: (team: Omit<Team, 'id' | 'createdAt'>) => void;
  
  // Campaigns
  campaigns: Campaign[];
  activeCampaign: Campaign | null;
  createCampaign: (campaign: Omit<Campaign, 'id' | 'createdAt'>) => void;
  
  // Sales
  sales: Sale[];
  addSale: (sale: Omit<Sale, 'id' | 'timestamp'>) => void;
  
  // Rankings
  ranking: RankingEntry[];
  
  // Notifications
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => void;
  clearNotifications: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock data
const mockTeam: Team = {
  id: 'team-1',
  name: 'Vendas Corporativas',
  logo: undefined,
  scoringType: 'monetary_value',
  displayType: 'percentage',
  isDefault: true,
  createdAt: new Date()
};

const mockCampaign: Campaign = {
  id: 'camp-1',
  name: 'Campanha Q1 2025',
  teamId: 'team-1',
  period: 'quarterly',
  startDate: new Date(2025, 0, 1),
  endDate: new Date(2025, 2, 31),
  autoReset: true,
  hideValues: false,
  prizes: [
    {
      id: 'prize-1',
      position: 1,
      name: 'Viagem para Europa',
      description: 'Viagem completa para dois destinos europeus',
      icon: '🏆',
      visible: true
    },
    {
      id: 'prize-2',
      position: 2,
      name: 'iPhone 15 Pro',
      description: 'Último lançamento da Apple',
      icon: '🥈',
      visible: true
    },
    {
      id: 'prize-3',
      position: 3,
      name: 'Tablet + Fones',
      description: 'Kit tecnologia premium',
      icon: '🥉',
      visible: true
    }
  ],
  targets: [
    { sellerId: '1', target: 100000, currentTotal: 75000, achievement: 75 },
    { sellerId: '2', target: 80000, currentTotal: 68000, achievement: 85 },
    { sellerId: '3', target: 90000, currentTotal: 45000, achievement: 50 },
    { sellerId: '4', target: 70000, currentTotal: 28000, achievement: 40 },
    { sellerId: '5', target: 85000, currentTotal: 63750, achievement: 75 }
  ],
  isActive: true,
  createdAt: new Date()
};

const mockRanking: RankingEntry[] = [
  {
    sellerId: '2',
    sellerName: 'Maria Santos',
    sellerPhoto: 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
    position: 1,
    previousPosition: 2,
    value: 68000,
    target: 80000,
    achievement: 85,
    prizes: [mockCampaign.prizes[0]]
  },
  {
    sellerId: '1',
    sellerName: 'João Silva',
    sellerPhoto: 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
    position: 2,
    previousPosition: 1,
    value: 75000,
    target: 100000,
    achievement: 75,
    prizes: [mockCampaign.prizes[1]]
  },
  {
    sellerId: '5',
    sellerName: 'Pedro Costa',
    sellerPhoto: 'https://images.pexels.com/photos/1438761/pexels-photo-1438761.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
    position: 3,
    previousPosition: 3,
    value: 63750,
    target: 85000,
    achievement: 75,
    prizes: [mockCampaign.prizes[2]]
  },
  {
    sellerId: '3',
    sellerName: 'Ana Oliveira',
    sellerPhoto: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
    position: 4,
    previousPosition: 4,
    value: 45000,
    target: 90000,
    achievement: 50,
    prizes: []
  },
  {
    sellerId: '4',
    sellerName: 'Carlos Lima',
    sellerPhoto: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
    position: 5,
    previousPosition: 5,
    value: 28000,
    target: 70000,
    achievement: 40,
    prizes: []
  }
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>({
    theme: 'light',
    soundsEnabled: true,
    selectedSounds: {
      sale: ['money', 'applause'],
      positionChange: 'racing',
      podiumEntry: 'achievement',
      firstPlace: 'victory'
    }
  });

  const [teams, setTeams] = useState<Team[]>([mockTeam]);
  const [activeTeam, setActiveTeam] = useState<Team | null>(mockTeam);
  const [campaigns, setCampaigns] = useState<Campaign[]>([mockCampaign]);
  const [activeCampaign, setActiveCampaign] = useState<Campaign | null>(mockCampaign);
  const [sales, setSales] = useState<Sale[]>([]);
  const [ranking, setRanking] = useState<RankingEntry[]>(mockRanking);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    // Apply theme to document
    document.documentElement.classList.toggle('dark', settings.theme === 'dark');
  }, [settings.theme]);

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const createTeam = (teamData: Omit<Team, 'id' | 'createdAt'>) => {
    const newTeam: Team = {
      ...teamData,
      id: `team-${Date.now()}`,
      createdAt: new Date()
    };
    setTeams(prev => [...prev, newTeam]);
  };

  const createCampaign = (campaignData: Omit<Campaign, 'id' | 'createdAt'>) => {
    const newCampaign: Campaign = {
      ...campaignData,
      id: `camp-${Date.now()}`,
      createdAt: new Date()
    };
    setCampaigns(prev => [...prev, newCampaign]);
  };

  const addSale = (saleData: Omit<Sale, 'id' | 'timestamp'>) => {
    const newSale: Sale = {
      ...saleData,
      id: `sale-${Date.now()}`,
      timestamp: new Date()
    };
    setSales(prev => [...prev, newSale]);

    // Update ranking
    setRanking(prev => {
      const updated = prev.map(entry => {
        if (entry.sellerId === saleData.sellerId) {
          const newValue = entry.value + saleData.value;
          const newAchievement = Math.round((newValue / entry.target) * 100);
          return { ...entry, value: newValue, achievement: newAchievement };
        }
        return entry;
      });

      // Sort by achievement percentage
      return updated.sort((a, b) => b.achievement - a.achievement).map((entry, index) => ({
        ...entry,
        previousPosition: entry.position,
        position: index + 1
      }));
    });

    // Add notification
    const seller = ranking.find(r => r.sellerId === saleData.sellerId);
    if (seller) {
      addNotification({
        type: 'sale',
        sellerId: saleData.sellerId,
        sellerName: seller.sellerName,
        message: `${seller.sellerName} realizou uma venda de R$ ${saleData.value.toLocaleString('pt-BR')}!`,
        soundEnabled: settings.soundsEnabled
      });
    }
  };

  const addNotification = (notificationData: Omit<Notification, 'id' | 'timestamp'>) => {
    const notification: Notification = {
      ...notificationData,
      id: `notif-${Date.now()}`,
      timestamp: new Date()
    };
    setNotifications(prev => [notification, ...prev.slice(0, 4)]);

    // Auto-remove after 5 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== notification.id));
    }, 5000);
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  return (
    <AppContext.Provider value={{
      settings,
      updateSettings,
      teams,
      activeTeam,
      setActiveTeam,
      createTeam,
      campaigns,
      activeCampaign,
      createCampaign,
      sales,
      addSale,
      ranking,
      notifications,
      addNotification,
      clearNotifications
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};