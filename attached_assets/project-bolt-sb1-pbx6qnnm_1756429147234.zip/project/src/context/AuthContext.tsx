import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, LoginCredentials, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => void;
  register: (userData: Partial<User> & { password: string }) => Promise<void>;
  loading: boolean;
  hasPermission: (permission: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user for development
const mockUser: User = {
  id: '1',
  email: 'admin@empresa.com',
  name: 'João Silva',
  cpf: '12345678901',
  photo: 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
  role: 'admin_with_visibility',
  teams: ['team-1'],
  createdAt: new Date(),
  isActive: true
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate checking for stored auth token
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      // Auto-login with mock user for demo
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
    }
    setLoading(false);
  }, []);

  const login = async (credentials: LoginCredentials): Promise<void> => {
    setLoading(true);
    try {
      // Mock login validation
      if (credentials.email && credentials.password.length >= 6) {
        const userData = { ...mockUser, email: credentials.email };
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
      } else {
        throw new Error('Credenciais inválidas');
      }
    } catch (error) {
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const register = async (userData: Partial<User> & { password: string }): Promise<void> => {
    setLoading(true);
    try {
      // Mock registration
      const newUser: User = {
        id: Date.now().toString(),
        email: userData.email!,
        name: userData.name!,
        cpf: userData.cpf!,
        photo: userData.photo,
        role: userData.role || 'seller_with_edit',
        teams: userData.teams || [],
        createdAt: new Date(),
        isActive: true
      };
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
    } catch (error) {
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const hasPermission = (permission: string): boolean => {
    if (!user) return false;

    const permissions: Record<UserRole, string[]> = {
      admin_with_visibility: ['all'],
      admin_without_visibility: ['manage', 'configure'],
      seller_with_edit: ['edit_own_sales', 'view'],
      seller_without_edit: ['view'],
      viewer: ['view_tv']
    };

    return permissions[user.role]?.includes('all') || permissions[user.role]?.includes(permission);
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      register,
      loading,
      hasPermission
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};